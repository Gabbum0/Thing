module.exports = {
    TOKEN: "not leaking my token this time",
    PREFIX: "l.",
    Roles: {
        Pending: "722624466995118131"
    }
}